"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp, Tag } from "lucide-react"

const daftarHarga = [
  {
    kategori: "Maryam",
    produk: [
      { nama: "Maryam Ori", harga: "Rp 20.000", isi: "isi 5" },
      { nama: "Maryam Pandang", harga: "Rp 20.000", isi: "isi 5" },
      { nama: "Maryam Daging", harga: "Rp 20.000", isi: "isi 3" },
      { nama: "Maryam Coklat", harga: "Rp 24.000", isi: "isi 5" },
      { nama: "Maryam Keju", harga: "Rp 24.000", isi: "isi 5" },
    ],
  },
  {
    kategori: "Donat",
    produk: [
      { nama: "Donat Kentang", harga: "Rp 27.000", isi: "isi 10" },
      { nama: "Roti Goreng Coklat", harga: "Rp 28.000", isi: "isi 10" },
    ],
  },
  {
    kategori: "Bolem",
    produk: [
      { nama: "Bolem Coklat", harga: "Rp 30.000", isi: "isi 10" },
      { nama: "Bolem Coklat Keju", harga: "Rp 30.000", isi: "isi 10" },
      { nama: "Bolem Keju Parut", harga: "Rp 30.000", isi: "isi 10" },
      { nama: "Bolem Stroberi", harga: "Rp 30.000", isi: "isi 10" },
      { nama: "Bolem Blueberry", harga: "Rp 30.000", isi: "isi 10" },
      { nama: "Bolem Vanila", harga: "Rp 30.000", isi: "isi 10" },
      { nama: "Bolem Kacang Ijo", harga: "Rp 30.000", isi: "isi 10" },
      { nama: "Bolem Keju MELT", harga: "Rp 31.000", isi: "isi 10" },
      { nama: "Bolem Selai Kacang", harga: "Rp 30.000", isi: "isi 10" },
    ],
  },
  {
    kategori: "Mamol",
    produk: [
      { nama: "Mamol Kacang Ijo", harga: "Rp 19.000", isi: "isi 10" },
      { nama: "Mamol Susu", harga: "Rp 20.000", isi: "isi 10" },
      { nama: "Mamol Coklat", harga: "Rp 20.000", isi: "isi 10" },
      { nama: "Mamol Keju", harga: "Rp 20.000", isi: "isi 10" },
    ],
  },
  {
    kategori: "Risol",
    produk: [
      { nama: "Kebab Mini", harga: "Rp 25.000", isi: "isi 5" },
      { nama: "Kebab Mini", harga: "Rp 45.000", isi: "isi 10" },
      { nama: "Risoles Sayur", harga: "Rp 30.000", isi: "isi 10" },
    ],
  },
  {
    kategori: "Kebab",
    produk: [
      { nama: "Kebab Mini", harga: "Rp 36.000", isi: "isi 10" },
      { nama: "Kebab Mozarella", harga: "Rp 40.000", isi: "isi 10" },
      { nama: "Kebab Keju", harga: "Rp 37.000", isi: "isi 10" },
    ],
  },
  {
    kategori: "Sambosa",
    produk: [
      { nama: "Sambosa Daging", harga: "Rp 35.000", isi: "isi 10" },
      { nama: "Sambosa Smoke Beef", harga: "Rp 35.000", isi: "isi 10" },
      { nama: "Sambosa Keju", harga: "Rp 35.000", isi: "isi 10" },
      { nama: "Sambosa Sayur", harga: "Rp 28.000", isi: "isi 10" },
    ],
  },
  {
    kategori: "Bapao",
    produk: [
      { nama: "Bapao Coklat", harga: "Rp 14.500", isi: "isi 5" },
      { nama: "Bapao Nten/Unti", harga: "Rp 14.500", isi: "isi 5" },
      { nama: "Bapao Kacang Ijo", harga: "Rp 14.500", isi: "isi 5" },
    ],
  },
  {
    kategori: "Kroket",
    produk: [
      { nama: "Bitterbalen", harga: "Rp 32.500", isi: "isi 10" },
      { nama: "Kroket Mozarella", harga: "Rp 35.000", isi: "isi 10" },
      { nama: "Kroket Melt", harga: "Rp 35.000", isi: "isi 10" },
      { nama: "Kroket Daging", harga: "Rp 38.000", isi: "isi 10" },
    ],
  },
  {
    kategori: "Dimsum",
    produk: [
      { nama: "Dimsum Ayam", harga: "Rp 29.000", isi: "isi 10" },
      { nama: "Dimsum Udang", harga: "Rp 32.000", isi: "isi 10" },
      { nama: "Dimsum Jamur", harga: "Rp 32.000", isi: "isi 10" },
      { nama: "Dimsum Mozarella", harga: "Rp 32.000", isi: "isi 10" },
      { nama: "Dimsum Ayam Mini", harga: "Rp 29.000", isi: "isi 20" },
    ],
  },
  {
    kategori: "Lainnya",
    produk: [
      { nama: "Tahu Baso Sapi", harga: "Rp 22.000", isi: "isi 10" },
      { nama: "Sosis Solo", harga: "Rp 25.000", isi: "isi 10" },
      { nama: "Pizza Mini", harga: "Rp 35.000", isi: "isi 10" },
      { nama: "Bitterbalen", harga: "Rp 36.500", isi: "isi 10" },
      { nama: "Pisang Molen", harga: "Rp 30.000", isi: "isi 10" },
      { nama: "Onde-onde", harga: "Rp 30.000", isi: "isi 10" },
      { nama: "Martabak", harga: "Rp 38.000", isi: "isi 10" },
      { nama: "Pastel", harga: "Rp 35.000", isi: "isi 10" },
      { nama: "Pastel Bihun + Daging", harga: "Rp 30.000", isi: "isi 10" },
      { nama: "Asidah", harga: "Rp 13.500", isi: "" },
      { nama: "Dimsum (kecil)", harga: "Rp 25.000", isi: "isi 3" },
      { nama: "Tortila Daging Moza", harga: "Rp 30.000", isi: "isi 5" },
      { nama: "Kulit Sambosa", harga: "Rp 50.000", isi: "isi 50" },
    ],
  },
]

export default function Harga() {
  const [openKategori, setOpenKategori] = useState<string[]>(["Dimsum", "Kroket"])

  const toggle = (k: string) => {
    setOpenKategori((prev) => (prev.includes(k) ? prev.filter((x) => x !== k) : [...prev, k]))
  }

  return (
    <section id="harga" className="py-16 md:py-20" style={{ backgroundColor: "var(--brand-light)" }}>
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-10">
          <span
            className="inline-block text-sm font-semibold px-4 py-1.5 rounded-full mb-3"
            style={{ backgroundColor: "var(--brand-blue)", color: "white" }}
          >
            <Tag size={13} className="inline mr-1" />
            Harga Grosir
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground text-balance">
            Daftar Harga Grosir Abi Frozen
          </h2>
          <p className="text-muted-foreground mt-3 max-w-md mx-auto leading-relaxed">
            Minimal pembelian grosir{" "}
            <strong className="text-foreground">Rp 1.500.000</strong>. Cocok untuk reseller dan pelaku usaha.
          </p>
        </div>

        <div className="flex flex-col gap-3">
          {daftarHarga.map((kat) => {
            const isOpen = openKategori.includes(kat.kategori)
            return (
              <div
                key={kat.kategori}
                className="bg-card rounded-2xl border border-border overflow-hidden shadow-sm"
              >
                <button
                  onClick={() => toggle(kat.kategori)}
                  className="w-full flex items-center justify-between px-5 py-4 text-left hover:bg-secondary/50 transition-colors"
                >
                  <span className="font-semibold text-foreground">{kat.kategori}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{kat.produk.length} produk</span>
                    {isOpen ? (
                      <ChevronUp size={18} className="text-muted-foreground" />
                    ) : (
                      <ChevronDown size={18} className="text-muted-foreground" />
                    )}
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-4 border-t border-border">
                    <div className="grid sm:grid-cols-2 gap-2 mt-3">
                      {kat.produk.map((p) => (
                        <div
                          key={p.nama}
                          className="flex items-center justify-between py-2 px-3 rounded-xl bg-secondary/40"
                        >
                          <div>
                            <p className="text-sm font-medium text-foreground">{p.nama}</p>
                            {p.isi && <p className="text-xs text-muted-foreground">{p.isi}</p>}
                          </div>
                          <p className="text-sm font-bold" style={{ color: "var(--brand-teal)" }}>
                            {p.harga}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>

        <div className="mt-8 text-center">
          <a
            href="https://wa.me/6208xxxxxxxxxx?text=Halo, saya ingin tanya tentang harga grosir Abi Frozen"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full text-sm font-bold text-white hover:opacity-90 transition-opacity shadow-md"
            style={{ backgroundColor: "var(--brand-blue)" }}
          >
            Tanya Harga Grosir via WhatsApp
          </a>
        </div>
      </div>
    </section>
  )
}
