import { Star, MapPin, Clock, Phone } from "lucide-react"

export default function Hero() {
  return (
    <section
      id="beranda"
      className="relative overflow-hidden"
      style={{ background: "linear-gradient(135deg, var(--brand-blue) 0%, var(--brand-teal) 100%)" }}
    >
      {/* Decorative circles */}
      <div className="absolute top-0 right-0 w-96 h-96 rounded-full opacity-10 bg-white -translate-y-1/2 translate-x-1/3" />
      <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full opacity-10 bg-white translate-y-1/2 -translate-x-1/3" />

      <div className="relative max-w-6xl mx-auto px-4 py-12 md:py-20">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          {/* Text */}
          <div className="text-white">
            <div className="inline-flex items-center gap-2 bg-white/20 rounded-full px-4 py-1.5 text-sm font-medium mb-4">
              <Star size={14} className="fill-yellow-300 text-yellow-300" />
              <span>4.712 Ulasan Google</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold leading-tight text-balance mb-4">
              Abi Frozen Food
              <span className="block text-2xl md:text-3xl font-normal opacity-90 mt-1">
                Lezat, Praktis & Siap Goreng!
              </span>
            </h1>
            <p className="text-white/85 leading-relaxed mb-8 text-base md:text-lg">
              Frozen food berkualitas tinggi dengan berbagai pilihan — dari dimsum, donat, kroket, hingga kebab
              mozarella. Cocok untuk cemilan, jualan, maupun kebutuhan keluarga sehari-hari.
            </p>

            {/* Info badges */}
            <div className="flex flex-wrap gap-3 mb-8">
              <span className="flex items-center gap-1.5 bg-white/20 rounded-full px-3 py-1.5 text-sm">
                <MapPin size={13} />
                Gg. Tongkol No.76, Panjunan, Cirebon
              </span>
              <span className="flex items-center gap-1.5 bg-white/20 rounded-full px-3 py-1.5 text-sm">
                <Clock size={13} />
                Sen–Sab: 08.00 – 17.00
              </span>
            </div>

            <div className="flex flex-wrap gap-3">
              <a
                href="https://wa.me/6208xxxxxxxxxx"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-white text-sm font-bold px-6 py-3 rounded-full hover:opacity-90 transition-opacity"
                style={{ color: "var(--brand-blue)" }}
              >
                <Phone size={16} />
                Order via WhatsApp
              </a>
              <a
                href="#produk"
                className="flex items-center gap-2 border-2 border-white text-white text-sm font-semibold px-6 py-3 rounded-full hover:bg-white/10 transition-colors"
              >
                Lihat Produk
              </a>
            </div>
          </div>

          {/* Hero images collage */}
          <div className="grid grid-cols-2 gap-3">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/g8WMvXkMdsQZyOoNoCLRM-Wz7kzZeQe2XqKb2xaF8fHJue6I1cp4.jpg"
              alt="Donat kantong Abi Frozen lembut bertabur gula halus"
              className="rounded-2xl object-cover w-full aspect-square shadow-xl"
            />
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/GpoCsEYsqyPJwasA7bnJq-Gbu1Yg2Nk7HJ95aPvBnqmBqg3EZUsT.jpg"
              alt="Pizza mini Abi Frozen dengan topping keju lumer"
              className="rounded-2xl object-cover w-full aspect-square shadow-xl mt-6"
            />
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/FSFUgkrMaDiUAcszsgkGl-en1nfwrKpOTaI1mBqyzLPkJHM3Xg0K.jpg"
              alt="Dimsum ayam Abi Frozen disajikan di piring putih dengan saus"
              className="rounded-2xl object-cover w-full aspect-square shadow-xl -mt-6"
            />
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/CQYnJLBAla9cw6WN3Ipc8-gaJV4wREGCZURx0yMYA4fwzLhxYyns.jpg"
              alt="Martabak Abi Frozen isi sayur dan telur gurih"
              className="rounded-2xl object-cover w-full aspect-square shadow-xl"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
