"use client"

import { useState } from "react"
import { Menu, X, ShoppingBag } from "lucide-react"

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  const links = [
    { label: "Beranda", href: "#beranda" },
    { label: "Produk", href: "#produk" },
    { label: "Harga Grosir", href: "#harga" },
    { label: "Tentang Kami", href: "#tentang" },
    { label: "Kontak", href: "#kontak" },
  ]

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm shadow-sm border-b border-border">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo */}
        <a href="#beranda" className="flex items-center gap-3">
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/5CZnEsmbcyhAz2yxmHG1O-mhlhF6Gw7m8hibRl1ykP6urIdq2IGe.jpg"
            alt="Logo Abi Frozen - toko frozen food Cirebon"
            className="h-12 w-12 object-contain rounded-xl"
          />
          <div>
            <p className="font-bold text-lg leading-none" style={{ color: "var(--brand-blue)" }}>
              Abi Frozen
            </p>
            <p className="text-xs text-muted-foreground leading-tight">Frozen Food Cirebon</p>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-foreground hover:text-primary transition-colors"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* CTA */}
        <a
          href="https://wa.me/6208xxxxxxxxxx"
          target="_blank"
          rel="noopener noreferrer"
          className="hidden md:flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-white transition-opacity hover:opacity-90"
          style={{ backgroundColor: "var(--brand-blue)" }}
        >
          <ShoppingBag size={16} />
          Order Sekarang
        </a>

        {/* Mobile Toggle */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden p-2 rounded-lg text-foreground"
          aria-label="Toggle menu"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-border px-4 py-4 flex flex-col gap-3">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setIsOpen(false)}
              className="text-sm font-medium text-foreground py-2 border-b border-border last:border-0"
            >
              {link.label}
            </a>
          ))}
          <a
            href="https://wa.me/6208xxxxxxxxxx"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-2 flex items-center justify-center gap-2 px-4 py-3 rounded-full text-sm font-semibold text-white"
            style={{ backgroundColor: "var(--brand-blue)" }}
          >
            <ShoppingBag size={16} />
            Order via WhatsApp
          </a>
        </div>
      )}
    </header>
  )
}
