import { MapPin, Clock, Star, Instagram, ShoppingBag } from "lucide-react"

export default function Kontak() {
  return (
    <>
      {/* About Section */}
      <section id="tentang" className="py-16 md:py-20 bg-card">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div>
              <span
                className="inline-block text-sm font-semibold px-4 py-1.5 rounded-full mb-4"
                style={{ backgroundColor: "var(--brand-light)", color: "var(--brand-blue)" }}
              >
                Tentang Kami
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground text-balance mb-4">
                Toko Frozen Food Terpercaya di Cirebon
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Abi Frozen berdiri sebagai salah satu toko frozen food terpercaya di Cirebon dengan lebih dari{" "}
                <strong className="text-foreground">4.700 ulasan positif</strong> di Google. Kami menyediakan
                berbagai produk frozen berkualitas tinggi, higienis, dan siap saji — mulai dari kue tradisional
                hingga snack modern.
              </p>
              <div className="flex flex-col gap-3">
                <div className="flex items-start gap-3">
                  <Star size={18} className="mt-0.5 fill-yellow-400 text-yellow-400 shrink-0" />
                  <p className="text-sm text-muted-foreground">
                    <strong className="text-foreground">4.712 ulasan bintang 5</strong> dari pelanggan setia kami
                    di Google Maps
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin size={18} className="mt-0.5 shrink-0" style={{ color: "var(--brand-teal)" }} />
                  <p className="text-sm text-muted-foreground">
                    Gg. Tongkol No.76, Panjunan, Kec. Lemahwungkuk, Kota Cirebon, Jawa Barat 45112
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <Clock size={18} className="mt-0.5 shrink-0" style={{ color: "var(--brand-teal)" }} />
                  <div className="text-sm text-muted-foreground">
                    <p>
                      <strong className="text-foreground">Senin – Sabtu:</strong> 08.00 – 17.00
                    </p>
                    <p>
                      <strong className="text-foreground">Minggu:</strong> Tutup
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Review cards */}
            <div className="flex flex-col gap-4">
              <div
                className="rounded-2xl p-5 border border-border"
                style={{ backgroundColor: "var(--brand-light)" }}
              >
                <div className="flex gap-1 mb-2">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} size={14} className="fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-sm text-foreground italic mb-2">
                  &ldquo;Roti goreng coklat dan pizza nya top banget, pelayanan nya sangat ramah&rdquo;
                </p>
                <p className="text-xs text-muted-foreground font-medium">— Abi ajah</p>
              </div>
              <div
                className="rounded-2xl p-5 border border-border"
                style={{ backgroundColor: "var(--brand-light)" }}
              >
                <div className="flex gap-1 mb-2">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} size={14} className="fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-sm text-foreground italic mb-2">
                  &ldquo;Kue nya macem-macem rasanya enak semua&rdquo;
                </p>
                <p className="text-xs text-muted-foreground font-medium">— Najmah87 Thalib</p>
              </div>
              <div
                className="rounded-2xl p-5 border border-border"
                style={{ backgroundColor: "var(--brand-light)" }}
              >
                <div className="flex gap-1 mb-2">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} size={14} className="fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-sm text-foreground italic mb-2">
                  &ldquo;Produknya enak-enak dan bervariasi. Cocok buat jualan lagi!&rdquo;
                </p>
                <p className="text-xs text-muted-foreground font-medium">— Pelanggan Setia</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact / CTA Section */}
      <section
        id="kontak"
        className="py-16 md:py-20"
        style={{ background: "linear-gradient(135deg, var(--brand-blue) 0%, var(--brand-teal) 100%)" }}
      >
        <div className="max-w-4xl mx-auto px-4 text-center">
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/5CZnEsmbcyhAz2yxmHG1O-mhlhF6Gw7m8hibRl1ykP6urIdq2IGe.jpg"
            alt="Logo Abi Frozen"
            className="h-20 w-20 object-contain rounded-2xl mx-auto mb-6 shadow-xl"
          />
          <h2 className="text-3xl md:text-4xl font-bold text-white text-balance mb-4">
            Yuk Order Sekarang!
          </h2>
          <p className="text-white/85 mb-8 max-w-md mx-auto leading-relaxed">
            Hubungi kami langsung via WhatsApp untuk pemesanan eceran maupun grosir. Minimal grosir Rp 1.500.000.
          </p>

          <div className="flex flex-wrap gap-4 justify-center mb-10">
            <a
              href="https://wa.me/6208xxxxxxxxxx?text=Halo Abi Frozen, saya ingin order frozen food"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-white text-sm font-bold px-8 py-3.5 rounded-full hover:opacity-90 transition-opacity shadow-lg"
              style={{ color: "var(--brand-blue)" }}
            >
              <ShoppingBag size={16} />
              Order via WhatsApp
            </a>
            <a
              href="https://wa.me/6208xxxxxxxxxx?text=Halo, saya ingin tanya harga grosir"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 border-2 border-white text-white text-sm font-semibold px-8 py-3.5 rounded-full hover:bg-white/10 transition-colors"
            >
              Tanya Harga Grosir
            </a>
          </div>

          <div className="border-t border-white/20 pt-8">
            <p className="text-white/70 text-sm mb-4">Ikuti kami di sosial media</p>
            <div className="flex gap-4 justify-center">
              <a
                href="https://instagram.com/abifrozen"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-white/80 hover:text-white text-sm transition-colors"
              >
                <Instagram size={16} />
                Instagram
              </a>
              <a
                href="https://tokopedia.com/abifrozen"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-white/80 hover:text-white text-sm transition-colors"
              >
                <ShoppingBag size={16} />
                Tokopedia
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-white py-8">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-white/60 text-sm">
            &copy; 2026 Abi Frozen Food — Gg. Tongkol No.76, Panjunan, Cirebon 45112
          </p>
          <p className="text-white/40 text-xs mt-1">Senin – Sabtu: 08.00 – 17.00 | Minggu: Tutup</p>
        </div>
      </footer>
    </>
  )
}
