"use client"

import { useState } from "react"

const kategori = ["Semua", "Kue & Pastry", "Gorengan Gurih", "Dimsum", "Frozen Spesial"]

const produk = [
  {
    nama: "Donat Kentang",
    deskripsi: "Donat kentang lembut bertabur gula halus, renyah di luar lembut di dalam",
    harga: "Rp 27.000",
    isi: "isi 10",
    kategori: "Kue & Pastry",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/g8WMvXkMdsQZyOoNoCLRM-Wz7kzZeQe2XqKb2xaF8fHJue6I1cp4.jpg",
    alt: "Donat kentang Abi Frozen berjajar rapi di atas nampan putih bertabur gula halus",
  },
  {
    nama: "Roti Goreng Coklat",
    deskripsi: "Roti goreng lembut isi coklat lumer, manis dan creamy",
    harga: "Rp 28.000",
    isi: "isi 10",
    kategori: "Kue & Pastry",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/NFwHqsG3yXs2AbTceFydJ-z6dqmZx2piTbmGAlhnnO8e0FI0hoJs.webp",
    alt: "Roti goreng coklat Abi Frozen isi coklat lumer di atas papan kayu",
  },
  {
    nama: "Pizza Mini",
    deskripsi: "Pizza mini dengan saus tomat, daging, dan keju parut lumer",
    harga: "Rp 35.000",
    isi: "isi 10",
    kategori: "Kue & Pastry",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/GpoCsEYsqyPJwasA7bnJq-Gbu1Yg2Nk7HJ95aPvBnqmBqg3EZUsT.jpg",
    alt: "Pizza mini Abi Frozen dengan topping keju lumer dan saus merah di atas loyang",
  },
  {
    nama: "Bapao Isi Nten/Unti",
    deskripsi: "Bapao lembut isi nten/unti manis, cocok untuk sarapan",
    harga: "Rp 14.500",
    isi: "isi 5",
    kategori: "Kue & Pastry",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/s2r4VjK14lTnQZTrZvTdV-Z1tNsY8ptSlofMIdcW6Cie5R16Qk9a.jpg",
    alt: "Bapao putih lembut isi nten manis di piring putih dengan Abi Frozen logo",
  },
  {
    nama: "Dimsum Ayam",
    deskripsi: "Dimsum ayam empuk dengan topping wortel parut, disajikan dengan saus",
    harga: "Rp 29.000",
    isi: "isi 10",
    kategori: "Dimsum",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/FSFUgkrMaDiUAcszsgkGl-en1nfwrKpOTaI1mBqyzLPkJHM3Xg0K.jpg",
    alt: "Dimsum ayam Abi Frozen melingkar di piring putih dengan saus hitam wijen di tengah",
  },
  {
    nama: "Bitterbalen",
    deskripsi: "Bitterbalen renyah di luar lembut di dalam, camilan khas Belanda yang gurih",
    harga: "Rp 36.500",
    isi: "isi 10",
    kategori: "Gorengan Gurih",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/FoCWCcmiGFu1dPQzkIOfT-Mvx8VcJ9YUqwD44pGgTA46cw4Z7rpk.jpg",
    alt: "Bitterbalen bulat berwarna kuning keemasan di atas daun selada hijau segar",
  },
  {
    nama: "Pastel Isi",
    deskripsi: "Pastel goreng crispy kuning keemasan, isi daging dan sayuran",
    harga: "Rp 35.000",
    isi: "isi 10",
    kategori: "Gorengan Gurih",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/E2YBtPyEdM9E5NhPisymF-gJqBLlaf2kpsmosVpmDWBlR64j1egi.jpg",
    alt: "Pastel goreng kuning keemasan berjajar di piring oval dengan daun selada",
  },
  {
    nama: "Kebab Mini",
    deskripsi: "Kebab mini dengan isian daging berbumbu, sayuran, dan saus special",
    harga: "Rp 36.000",
    isi: "isi 10",
    kategori: "Gorengan Gurih",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/NbUWXIkVMIKIX9mzbI1uA-IqmbIhVtJhIw9s4sYAygOHO1lPxO8b.jpg",
    alt: "Kebab mini Abi Frozen ditata di atas papan kayu dengan isian daging terlihat",
  },
  {
    nama: "Sambosa Daging",
    deskripsi: "Sambosa crispy isi daging berbumbu rempah khas Timur Tengah",
    harga: "Rp 35.000",
    isi: "isi 10",
    kategori: "Gorengan Gurih",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/8XhsA1lABp1KcHlQMcpCJ-Y1xH1IsYxGYie1YlU0PeWpt4lcLqBx.jpg",
    alt: "Sambosa daging goreng crispy berbentuk segitiga berwarna coklat keemasan",
  },
  {
    nama: "Martabak Isi",
    deskripsi: "Martabak isi sayur bayam, telur, dan daging cincang berbumbu",
    harga: "Rp 38.000",
    isi: "isi 10",
    kategori: "Gorengan Gurih",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/CQYnJLBAla9cw6WN3Ipc8-gaJV4wREGCZURx0yMYA4fwzLhxYyns.jpg",
    alt: "Martabak Abi Frozen isi bayam dan telur dengan tampilan isian yang lezat",
  },
  {
    nama: "Tahu Baso Sapi",
    deskripsi: "Tahu isi baso sapi, gurih dan kenyal, favorit semua usia",
    harga: "Rp 22.000",
    isi: "isi 10",
    kategori: "Frozen Spesial",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/87GuNgQeEBZoUaA6yEWDb-A8y7Z6Vl2PketE6utWYNlRDiIIQuuG.jpg",
    alt: "Tahu baso sapi goreng Abi Frozen di piring bermotif bunga",
  },
  {
    nama: "Maryam Original",
    deskripsi: "Roti maryam original lapis-lapis, gurih dan cocok dengan kari",
    harga: "Rp 20.000",
    isi: "isi 5",
    kategori: "Frozen Spesial",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/rbP8jQ2C7C5DVhtvH2nU3-pMJxvOJEenoOl8lXNdh2kgelHaVB6d.jpg",
    alt: "Roti maryam original berlapis kuning keemasan di atas piring oval putih",
  },
  {
    nama: "Mamol Coklat",
    deskripsi: "Mamol manis isi coklat lumer, camilan favorit anak-anak",
    harga: "Rp 20.000",
    isi: "isi 10",
    kategori: "Kue & Pastry",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/tiCGZ33ENdBkSKsc7rAtT-CHQcecw5KOx6Ckfco6SC4532wH0sf3.jpg",
    alt: "Mamol coklat Abi Frozen berwarna kuning di piring putih dengan isian coklat terlihat",
  },
  {
    nama: "Sambosa Daging",
    deskripsi: "Sambosa crispy isi daging berbumbu rempah khas Timur Tengah",
    harga: "Rp 35.000",
    isi: "isi 10",
    kategori: "Gorengan Gurih",
    gambar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/api-attachments/EmFVS968rc6DxHicxf58G-1tU9H4xJIJxddejgwCp5aOqMLaCu8q.jpg",
    alt: "Sambosa daging Abi Frozen dibelah memperlihatkan isian daging berbumbu",
  },
]

export default function Produk() {
  const [activeKategori, setActiveKategori] = useState("Semua")

  const filtered = activeKategori === "Semua" ? produk : produk.filter((p) => p.kategori === activeKategori)

  return (
    <section id="produk" className="py-16 md:py-20 bg-background">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-10">
          <span
            className="inline-block text-sm font-semibold px-4 py-1.5 rounded-full mb-3"
            style={{ backgroundColor: "var(--brand-light)", color: "var(--brand-blue)" }}
          >
            Menu Unggulan
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground text-balance">
            Produk Frozen Food Kami
          </h2>
          <p className="text-muted-foreground mt-3 max-w-xl mx-auto leading-relaxed">
            Semua produk dibuat dengan bahan pilihan, higienis, dan siap digoreng langsung dari freezer.
          </p>
        </div>

        {/* Filter tabs */}
        <div className="flex flex-wrap gap-2 justify-center mb-10">
          {kategori.map((k) => (
            <button
              key={k}
              onClick={() => setActiveKategori(k)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                activeKategori === k
                  ? "text-white shadow-md"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              }`}
              style={activeKategori === k ? { backgroundColor: "var(--brand-blue)" } : {}}
            >
              {k}
            </button>
          ))}
        </div>

        {/* Product grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {filtered.map((item) => (
            <div
              key={item.nama}
              className="bg-card rounded-2xl overflow-hidden shadow-sm border border-border hover:shadow-lg transition-shadow group"
            >
              <div className="overflow-hidden aspect-square">
                <img
                  src={item.gambar}
                  alt={item.alt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-3 md:p-4">
                <h3 className="font-semibold text-sm md:text-base text-foreground leading-tight mb-1">
                  {item.nama}
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed mb-2 line-clamp-2">
                  {item.deskripsi}
                </p>
                <div className="flex items-center justify-end mt-auto">
                  <a
                    href={`https://wa.me/6208xxxxxxxxxx?text=Halo, saya ingin order ${encodeURIComponent(item.nama)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-semibold px-3 py-1.5 rounded-full text-white transition-opacity hover:opacity-80"
                    style={{ backgroundColor: "var(--brand-blue)" }}
                  >
                    Order
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
