import Navbar from "@/components/navbar"
import Hero from "@/components/hero"
import Produk from "@/components/produk"
import Harga from "@/components/harga"
import Kontak from "@/components/kontak"

export default function Page() {
  return (
    <main>
      <Navbar />
      <Hero />
      <Produk />
      <Harga />
      <Kontak />
    </main>
  )
}
